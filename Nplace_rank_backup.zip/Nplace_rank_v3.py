from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from threading import Thread
from selenium import webdriver
import selenium.common.exceptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from apscheduler.executors.pool import ThreadPoolExecutor as APSchedulerThreadPoolExecutor
from time import sleep, strftime, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
import random
import threading

from requests.exceptions import HTTPError

import mysql.connector
from flask_caching import Cache

from apscheduler.schedulers.background import BackgroundScheduler


app = Flask(__name__)
app.secret_key = 'nplace_rank_secret_key'

conn = mysql.connector.connect(
        host='192.168.0.26',
        user='test',
        password='tpals0430',
        database='nplace_rank_db'
)

def get_db_connection():
    # 새로운 데이터베이스 커넥션을 생성합니다.
    return mysql.connector.connect(
        host='192.168.0.26',
        user='test',
        password='tpals0430',
        database='nplace_rank_db'
    )

############## APScheduler 함수 실행 부분


scheduler = BackgroundScheduler(daemon=True, timezone='Asia/Seoul')

scheduler.start()

# 플레이스 URL로 플레이스ID 추출하는 함수
def split_url(url):
    first_split = url.split('/')
    last_split = first_split[-1].split('?')
    
    return last_split[0]


cursor = conn.cursor()

class ThreadWithReturnValue(Thread):
    def __init__(self, group=None, target=None, name=None, args=(), kwargs={}, Verbose=None):
        Thread.__init__(self, group, target, name, args, kwargs)
        self._return = None

    def run(self):
        if self._target is not None:
            self._return = self._target(*self._args, **self._kwargs)

    def join(self, *args):
        Thread.join(self, *args)
        return self._return


###################################################### 네이버 키워드별 전체 순위 검색 코드 시작 ###################################################### 

def get_naver_rank(keyword, 업체_ID, max_retries=2):
    options = webdriver.ChromeOptions()
    options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')
    options.add_argument('window-size=1380,900')
    options.add_argument('headless=new')
    options.add_argument("disable-gpu")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-infobars")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("prefs", {"profile.managed_default_content_settings.images": 2})  # 이미지 비활성화
    
    retry_count = 0
    result = None

    while retry_count < max_retries:
        sleep(random.uniform(0.5, 2))
        driver = None
        try:
            if driver is None:
                driver = webdriver.Chrome(options=options)

            URL = f"https://m.search.naver.com/search.naver?where=m&sm=top_sly.hst&fbm=0&acr=1&ie=utf8&query={keyword}"
            driver.get(url=URL)
            
            sleep(1)

            # sleep 제거 또는 최소화
            WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, 'place-app-root')))

            # 기존 로직 실행
            place_or_loc = driver.find_element(By.ID, 'place-app-root').find_element(By.XPATH, './div[last()]').get_attribute('id')
            펼쳐서_더보기 = driver.find_element(By.CLASS_NAME, 'place_section.Owktn').find_element(By.XPATH, './div[last()]').get_attribute('class')

            if place_or_loc == 'place-main-section-root':
                if 펼쳐서_더보기 == 'rdX0R':
                    펼쳐서_더보기_셀렉터 = "#place-main-section-root > div > div.rdX0R > div > a"
                elif 펼쳐서_더보기 == 'rdX0R POx9H':
                    펼쳐서_더보기_셀렉터 = "#place-main-section-root > div > div.rdX0R.POx9H > div > a"
            elif place_or_loc == 'loc-main-section-root':
                if 펼쳐서_더보기 == 'rdX0R':
                    펼쳐서_더보기_셀렉터 = "#loc-main-section-root > div > div.rdX0R > div > a"
                elif 펼쳐서_더보기 == 'rdX0R POx9H':
                    펼쳐서_더보기_셀렉터 = "#loc-main-section-root > div > div.rdX0R.POx9H > div > a"
            else:
                return '플레이스 조회와 관련이 없는 키워드 또는 업체'

            펼쳐서_더보기_엘리먼트 = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, 펼쳐서_더보기_셀렉터))
            )
            펼쳐서_더보기_엘리먼트.click()

            if place_or_loc == 'place-main-section-root':
                더보기_셀렉터 = "#place-main-section-root > div > div.M7vfr > a"
            elif place_or_loc == 'loc-main-section-root':
                더보기_셀렉터 = "#loc-main-section-root > div > div.M7vfr > a"

            WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CSS_SELECTOR, 더보기_셀렉터))).click()

            전체_엘리먼트들 = []
            타겟_업체_인덱스 = -1

            while True:
                for _ in range(9):  # 키 입력 횟수 최소화
                    ActionChains(driver).send_keys(u'\ue004').perform()
                for _ in range(6):  # 키 입력 횟수 최소화
                    ActionChains(driver).send_keys(u'\ue010').perform()
                    sleep(0.4)

                엘리먼트_클래스 = driver.find_element(By.CLASS_NAME, 'eDFz9').find_element(By.XPATH, './/li').get_attribute('class')
                엘리먼트_클래스2 = 엘리먼트_클래스.split(' ')

                if 엘리먼트_클래스2[0] != '':
                    엘리먼트들 = driver.find_elements(By.CLASS_NAME, 엘리먼트_클래스2[0])
                else:
                    return "잘못된 키워드"

                for 엘리먼트 in 엘리먼트들:
                    if len(엘리먼트_클래스2) > 1:
                        if 엘리먼트_클래스2[1] not in 엘리먼트.get_attribute("class"):
                            전체_엘리먼트들.append(엘리먼트)
                            if 업체_ID in 엘리먼트.find_element(By.TAG_NAME, "a").get_attribute("href"):
                                타겟_업체_인덱스 = len(전체_엘리먼트들) - 1
                    else:
                        전체_엘리먼트들.append(엘리먼트)
                        if 업체_ID in 엘리먼트.find_element(By.TAG_NAME, "a").get_attribute("href"):
                            타겟_업체_인덱스 = len(전체_엘리먼트들) - 1
                
                if 타겟_업체_인덱스 == -1:
                    result = '-'
                    driver.quit()
                    return result
            
                if 타겟_업체_인덱스 != -1:
                    rank = 타겟_업체_인덱스 + 1
                    result = f"{rank}위"
                    break

                if not 엘리먼트들:
                    result = '-'
                    break

            break  # 성공 시 루프 탈출

        except (selenium.common.TimeoutException, selenium.common.WebDriverException, HTTPError) as e:
            retry_count += 1
            
            if "429" in str(e):
                backoff_time = 2 ** retry_count
                print(f"429 Error: Waiting for keyword: {keyword}, 업체_ID: {업체_ID}, {backoff_time} seconds before retrying...")
                sleep(backoff_time)
                
            print(f"Error occurred for keyword: {keyword}, 업체_ID: {업체_ID}. Retry {retry_count}/{max_retries}. Exception: {e}")
            
            if retry_count == max_retries:
                result = f"Failed after {max_retries} retries"
            print(f"Unexpected error: {e}")
            
            result = f"오류 발생 : 관리자 문의"
            break

        finally:
            if driver:
                driver.quit()

    if retry_count == max_retries and result is None:
        result = "TimeoutException: Max retries reached"

    return result

### 키워드 30개씩 분할하여 순차적으로 실행하고, 처리 시간을 기록하는 코드

def update_keyword_results_in_batches(batch, batch_number):
    start_time = time()  # 시작 시간 기록

    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_keyword = {executor.submit(get_naver_rank, keyword, place_id): (user_id, place_id, keyword) for user_id, place_id, keyword in batch}

        for future in as_completed(future_to_keyword):
            user_id, place_id, keyword = future_to_keyword[future]
            try:
                result = future.result()
                cursor.execute('INSERT INTO keyword_result (user_id, place_id, keyword, search_date, result) VALUES (%s, %s, %s, %s, %s)',
                               (user_id, place_id, keyword, strftime('%Y-%m-%d'), result))
            except Exception as e:
                cursor.execute('UPDATE keyword_result SET result = %s WHERE user_id = %s AND place_id = %s AND keyword = %s AND search_date = %s',
                               (result, user_id, place_id, keyword, strftime('%Y-%m-%d')))
                print(f"Error processing keyword {keyword}, {result}: {e}")

    conn.commit()

    end_time = time()  # 종료 시간 기록
    elapsed_time = end_time - start_time
    print(f"Batch {batch_number} processed in {elapsed_time:.2f} seconds")

def update_keyword_results():
    cursor.execute('SELECT DISTINCT user_id, place_id, keyword FROM keyword_result ORDER BY user_id ASC')
    unique_keywords = cursor.fetchall()

    # 키워드 리스트를 30개씩 분할
    batches = [unique_keywords[i:i + 30] for i in range(0, len(unique_keywords), 30)]

    # 5분 간격으로 각 배치를 실행
    for index, batch in enumerate(batches):
        scheduler.add_job(update_keyword_results_in_batches, args=[batch, index + 1], trigger='date', next_run_time=datetime.now() + timedelta(minutes=5 * index))

    # 모든 배치가 완료된 후 스케줄러 종료 및 retry_failed_keywords_job 시작 예약
    final_run_time = datetime.now() + timedelta(minutes=5 * (len(batches) - 1))
    scheduler.add_job(start_retry_failed_keywords_job, trigger='date', next_run_time=final_run_time + timedelta(minutes=10))

# 주기적 작업 추가 (매일 정해진 시간에 실행하도록 설정)
#scheduler = BackgroundScheduler()
#scheduler.add_job(id='update_keyword_results_job', func=update_keyword_results, trigger='cron', minute="55", second='10', misfire_grace_time=60)

#scheduler.start()

###################################################### 네이버 키워드별 전체 순위 검색 코드 끝끝 ###################################################### 


###################################################### 오류 키워드들 전체 순위 검색 재실행 코드 ###################################################### 

def start_retry_failed_keywords_job():
    print("Starting retry_failed_keywords_job after update_keyword_results completion.")

    # 8시간 동안 10분 간격으로 retry_failed_keywords_job 실행
    end_time = datetime.now() + timedelta(hours=8)
    scheduler.add_job(retry_failed_keywords, id='retry_failed_keywords_job', trigger='interval', minutes=10, start_date=datetime.now(), end_date=end_time)

### 실패한 키워드를 재시도하는 함수

def retry_failed_keywords():
    today = datetime.now().strftime('%Y-%m-%d')

    # '오류'텍스트를 포함한 result 레코드들 가져오기
    cursor.execute('SELECT place_id, keyword FROM keyword_result WHERE search_date = %s AND result LIKE %s', (today, '%오류%'))
    failed_keywords = cursor.fetchall()
    
    print(f"Found {len(failed_keywords)} failed keywords.")
    
    if not failed_keywords:
        print("No failed keywords found.")
        return

    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_keyword = {
            executor.submit(get_naver_rank, keyword, place_id): (place_id, keyword) for place_id, keyword in failed_keywords
        }

        for future in as_completed(future_to_keyword):
            place_id, keyword = future_to_keyword[future]
            try:
                result = future.result()
                # 결과 업데이트
                cursor.execute(
                    'UPDATE keyword_result SET result = %s WHERE place_id = %s AND keyword = %s AND search_date = %s',
                    (result, place_id, keyword, today)
                )
            except Exception as e:
                print(f"Error processing keyword {keyword} for place_id {place_id}: {e}")

    # 변경사항을 커밋
    conn.commit()

# 스케줄러 설정 및 초기 실행
scheduler = BackgroundScheduler(executors={'default': APSchedulerThreadPoolExecutor(20)})

# update_keyword_results 작업을 매일 정해진 시간에 실행하도록 설정
scheduler.add_job(id='update_keyword_results_job', func=update_keyword_results, trigger='cron', minute="41", second='10', misfire_grace_time=60)

# 스케줄러 시작
scheduler.start()
###################################################### 오류 키워드들 전체 순위 검색 재실행 코드 ###################################################### 

###################################################### 24 08 28 TOP 100 키워드 실행 구문 테스트 시작 ###################################################### 

# 0. get_place_rank 함수 부분, TOP 100개 키워드를 기준으로 키워드별 업체 플레이스 ID 리스트 형식으로 산출

def get_keyword_rank(keyword):
    options = webdriver.ChromeOptions()
    options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')
    options.add_argument('window-size=1380,900')
    options.add_argument('headless=new')
    options.add_argument("disable-gpu")
    driver = webdriver.Chrome(options=options)
    
    result_placeid = []

    URL = f"https://m.search.naver.com/search.naver?where=m&sm=top_sly.hst&fbm=0&acr=1&ie=utf8&query={keyword}"
    driver.get(url=URL)

    sleep(1)

    try:
        place_or_loc = driver.find_element(By.ID, 'place-app-root').find_element(By.XPATH, './div[last()]').get_attribute('id')
        펼쳐서_더보기 = driver.find_element(By.CLASS_NAME, 'place_section.Owktn').find_element(By.XPATH, './div[last()]').get_attribute('class')

        if place_or_loc == 'place-main-section-root':
            if 펼쳐서_더보기 == 'rdX0R':
                펼쳐서_더보기_셀렉터 = "#place-main-section-root > div > div.rdX0R > div > a"
            elif 펼쳐서_더보기 == 'rdX0R POx9H':
                펼쳐서_더보기_셀렉터 = "#place-main-section-root > div > div.rdX0R.POx9H > div > a"
        elif place_or_loc == 'loc-main-section-root':
            if 펼쳐서_더보기 == 'rdX0R':
                펼쳐서_더보기_셀렉터 = "#loc-main-section-root > div > div.rdX0R > div > a"
            elif 펼쳐서_더보기 == 'rdX0R POx9H':
                펼쳐서_더보기_셀렉터 = "#loc-main-section-root > div > div.rdX0R.POx9H > div > a"
        else:
            driver.quit()
            return '플레이스 조회와 관련이 없는 키워드 또는 업체'

        펼쳐서_더보기_엘리먼트 = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 펼쳐서_더보기_셀렉터))
        )
        펼쳐서_더보기_엘리먼트.click()

        if place_or_loc == 'place-main-section-root':
            더보기_셀렉터 = "#place-main-section-root > div > div.M7vfr > a"
        elif place_or_loc == 'loc-main-section-root':
            더보기_셀렉터 = "#loc-main-section-root > div > div.M7vfr > a"
        
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, 더보기_셀렉터))).click()

        전체_엘리먼트들 = []
        타겟_업체_인덱스 = -1

        while True:
            for _ in range(9):
                ActionChains(driver).send_keys(u'\ue004').perform()
            for _ in range(6):
                ActionChains(driver).send_keys(u'\ue010').perform()
                sleep(0.4)
            
            엘리먼트_클래스 = driver.find_element(By.CLASS_NAME, 'eDFz9').find_element(By.XPATH, './/li').get_attribute('class')
            엘리먼트_클래스2 = 엘리먼트_클래스.split(' ')
            
            if 엘리먼트_클래스2[0] != '':
                엘리먼트들 = driver.find_elements(By.CLASS_NAME, 엘리먼트_클래스2[0])
            else:
                엘리먼트들 = []
                driver.quit()
                return "잘못된 키워드"
            
            for 엘리먼트 in 엘리먼트들:
                if len(엘리먼트_클래스2) > 1:
                    if 엘리먼트_클래스2[1] not in 엘리먼트.get_attribute("class"):
                        전체_엘리먼트들.append(엘리먼트)
                else:
                    전체_엘리먼트들.append(엘리먼트)
            
            for i, 엘리먼트 in enumerate(전체_엘리먼트들, start=1):
                place_url = 엘리먼트.find_element(By.TAG_NAME, "a").get_attribute("href")
                result_url = split_url(place_url)
                result_placeid.append(result_url)
            
            if not 엘리먼트들:
                driver.quit()
                return f"-"
            
            return result_placeid

    except Exception as e:
        driver.quit()
        print({e})
        return f"오류 발생 : 관리자 문의"

# 1. keyword_result 테이블에서 상위 100개의 키워드를 추출하여 반환
def get_top_keywords():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT DISTINCT keyword FROM keyword_result LIMIT 100
    """)
    top_keywords = [row[0] for row in cursor.fetchall()]
    print(top_keywords)
    conn.close()
    return top_keywords

# 3. place_id를 비교하고 keyword_result 테이블을 갱신하는 함수
def update_keyword_result(cursor, place_id, keyword, result):
    today_date = datetime.now().strftime("%Y-%m-%d")
    result_rank = str(result) + '위'

    # users 테이블에서 user_id 가져오기
    cursor.execute("SELECT id FROM users WHERE place_id = ?", (place_id,))
    user_id_row = cursor.fetchone()

    if not user_id_row:
        raise ValueError(f"User with place_id {place_id} not found.")
    
    user_id = user_id_row[0]

    # Check if the record exists for the given place_id and keyword
    cursor.execute("""
        SELECT search_date FROM keyword_result 
        WHERE place_id = ? AND keyword = ? ORDER BY search_date DESC LIMIT 1
    """, (place_id, keyword))
    row = cursor.fetchone()

    if row:
        current_search_date = row[0]
        
        # Only update if search_date is today, otherwise insert new
        if str(current_search_date) == str(today_date):
            cursor.execute("""
                UPDATE keyword_result
                SET result = ?
                WHERE place_id = ? AND keyword = ? AND search_date = ?
            """, (result_rank, place_id, keyword, today_date))
        else:
            cursor.execute("""
                INSERT INTO keyword_result (user_id, place_id, keyword, search_date, result)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, place_id, keyword, today_date, result_rank))
    else:
        cursor.execute("""
            INSERT INTO keyword_result (user_id, place_id, keyword, search_date, result)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, place_id, keyword, today_date, result_rank))


# 2. 각 키워드를 이용하여 get_keyword_rank 함수를 병렬로 호출하고 결과 처리
def process_keyword(keyword):
    conn = get_db_connection()
    cursor = conn.cursor(prepared=True)
    try:
        # keyword_result 테이블에서 해당 키워드에 대한 중복 없는 place_id를 가져옴
        cursor.execute("""
            SELECT DISTINCT place_id FROM keyword_result WHERE keyword = ?
        """, (keyword,))
        existing_place_ids = set(row[0] for row in cursor.fetchall())
    except Exception as e:
        print(f"Error fetching place_ids from the database: {e}")
        conn.close()
        return

    # get_keyword_rank 함수를 호출하여 각 키워드에 대해 place_ids 리스트 반환
    place_ids = []
    place_ids = get_keyword_rank(keyword)
    print(f"Place IDs from get_keyword_rank for {keyword}: {len(place_ids)}")

    # 반환된 place_ids와 기존의 place_ids를 비교하여 업데이트 수행
    try:
        for index, place_id in enumerate(place_ids):
            if place_id in existing_place_ids:
                # 각 place_id에 대해 업데이트 수행
                update_keyword_result(cursor, place_id, keyword, index + 1)
                
    except Exception as e:
        print(f"Error during updating keyword result: {e}")
    
    conn.commit()
    conn.close()

# 메인 함수: 상위 키워드를 병렬로 처리
def process_keywords():
    top_keywords = get_top_keywords()

    # 병렬로 process_keyword 함수를 실행
    with ThreadPoolExecutor(max_workers=10) as executor:
        executor.map(process_keyword, top_keywords)

# 4. 스케줄러 설정 - 매일 오후 2시에 실행
scheduler = BackgroundScheduler()
scheduler.add_job(func=process_keywords, trigger='cron', hour=14)
scheduler.add_job(id='update_top100_results_job', func=process_keywords, trigger='cron', minute="10", second='10', misfire_grace_time=60)
scheduler.start()
###################################################### 24 08 28 TOP 100 키워드 실행 구문 테스트 끝 ###################################################### 
    
def get_naver_rank_public(keyword, 업체_ID):
    options = webdriver.ChromeOptions()
    options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')
    options.add_argument('window-size=1380,900')
    options.add_argument('headless=new')
    options.add_argument("disable-gpu")
    driver = webdriver.Chrome(options=options)

    URL = f"https://m.search.naver.com/search.naver?where=m&sm=top_sly.hst&fbm=0&acr=1&ie=utf8&query={keyword}"
    driver.get(url=URL)
    print("퍼블릭")
    sleep(1)

    try:
        place_or_loc = driver.find_element(By.ID, 'place-app-root').find_element(By.XPATH, './div[last()]').get_attribute('id')
        펼쳐서_더보기 = driver.find_element(By.CLASS_NAME, 'place_section.Owktn').find_element(By.XPATH, './div[last()]').get_attribute('class')

        if place_or_loc == 'place-main-section-root':
            if 펼쳐서_더보기 == 'rdX0R':
                펼쳐서_더보기_셀렉터 = "#place-main-section-root > div > div.rdX0R > div > a"
            elif 펼쳐서_더보기 == 'rdX0R POx9H':
                펼쳐서_더보기_셀렉터 = "#place-main-section-root > div > div.rdX0R.POx9H > div > a"
        elif place_or_loc == 'loc-main-section-root':
            if 펼쳐서_더보기 == 'rdX0R':
                펼쳐서_더보기_셀렉터 = "#loc-main-section-root > div > div.rdX0R > div > a"
            elif 펼쳐서_더보기 == 'rdX0R POx9H':
                펼쳐서_더보기_셀렉터 = "#loc-main-section-root > div > div.rdX0R.POx9H > div > a"
        else:
            driver.quit()
            return '플레이스 조회와 관련이 없는 키워드 또는 업체'

        펼쳐서_더보기_엘리먼트 = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 펼쳐서_더보기_셀렉터))
        )
        펼쳐서_더보기_엘리먼트.click()

        if place_or_loc == 'place-main-section-root':
            더보기_셀렉터 = "#place-main-section-root > div > div.M7vfr > a"
        elif place_or_loc == 'loc-main-section-root':
            더보기_셀렉터 = "#loc-main-section-root > div > div.M7vfr > a"
        
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, 더보기_셀렉터))).click()

        전체_엘리먼트들 = []
        result_store_list_fin = []
        result_company_list = []
        타겟_업체_인덱스 = -1

        while True:
            for _ in range(7):
                ActionChains(driver).send_keys(u'\ue004').perform()
            for _ in range(6):
                ActionChains(driver).send_keys(u'\ue010').perform()
                sleep(0.4)
            
            엘리먼트_클래스 = driver.find_element(By.CLASS_NAME, 'eDFz9').find_element(By.XPATH, './/li').get_attribute('class')
            엘리먼트_클래스2 = 엘리먼트_클래스.split(' ')
            
            if 엘리먼트_클래스2[0] != '':
                엘리먼트들 = driver.find_elements(By.CLASS_NAME, 엘리먼트_클래스2[0])
            else:
                엘리먼트들 = []
                driver.quit()
                return "잘못된 키워드"
            
            for 엘리먼트 in 엘리먼트들:
                if len(엘리먼트_클래스2) > 1:
                    if 엘리먼트_클래스2[1] not in 엘리먼트.get_attribute("class"):
                        전체_엘리먼트들.append(엘리먼트)
                        if 업체_ID in 엘리먼트.find_element(By.TAG_NAME, "a").get_attribute("href"):
                            타겟_업체_인덱스 = len(전체_엘리먼트들) - 1
                else:
                    전체_엘리먼트들.append(엘리먼트)
                    if 업체_ID in 엘리먼트.find_element(By.TAG_NAME, "a").get_attribute("href"):
                        타겟_업체_인덱스 = len(전체_엘리먼트들) - 1
            
            ## 100개 ~ 300개 업체 전체 리스트 추출 구문.
            for i, 엘리먼트 in enumerate(전체_엘리먼트들, start=1):
                company_name = 엘리먼트.find_element(By.CLASS_NAME, "place_bluelink").text
                result_store_list = f"{i}. {company_name}\n"
                result_company_list.append(company_name)
                result_store_list_fin.append(result_store_list)
            
            print(result_store_list_fin)
            rank = 타겟_업체_인덱스 + 1
            
           
            if 타겟_업체_인덱스 != -1:
                rank = 타겟_업체_인덱스 + 1
                 ## 입력한 가게 상호 출력 구문
                store_name = 전체_엘리먼트들[타겟_업체_인덱스].find_element(By.CLASS_NAME, "place_bluelink").text
                result = f"{rank}위"
                driver.quit()
                return result, store_name, result_store_list_fin, result_company_list, keyword
            
            elif 타겟_업체_인덱스 == -1:
                result = '-'
                 ## 입력한 가게 상호 출력 구문
                store_name = "키워드 가게 목록에 없는 상호명"
                driver.quit()
                return result, store_name, result_store_list_fin, result_company_list, keyword
                
            if not 엘리먼트들:
                driver.quit()
                return f"-"
            
    except Exception as e:
        driver.quit()
        print({e})
        return f"오류 발생 : 관리자 문의"
    
@app.route('/')
def index():
    if 'id' in session:
        return redirect(url_for('Nplace-rank-check'))
    else:
        return redirect(url_for('login'))
    
@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        cursor.execute('SELECT * FROM users WHERE id = %s AND password = %s', (username, password))
        account = cursor.fetchone()

        if account:
            session['user_id'] = account[1]
            session['place_id'] = account[4]
            session['username'] = account[3]
            return redirect(url_for('home'))
        else:
            error = 'Invalid Credentials. Please try again.'
            return render_template('login.html', error=error)
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('id', None)
    return redirect(url_for('home'))

@app.route('/Nplace-rank-check', methods=['GET', 'POST'])
def Nplace_rank_check():
    if 'username' not in session:
        return redirect(url_for('login'))

    # 데이터베이스 연결 열기
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        user_id = session['user_id']
        cursor.execute('SELECT * FROM users WHERE id = %s', [user_id])
        user_info = cursor.fetchone()

        place_id = user_info[4]
        
        if user_info[5] is None: 
            user_info[5] = datetime(2020,1,1)

        vip_date = datetime.strptime(str(user_info[5]), "%Y-%m-%d")
        today = datetime.now().strftime("%Y-%m-%d")
        today = datetime.strptime(str(today), "%Y-%m-%d")
        day_check = vip_date - today

        if day_check.days < 0:
            max_keywords = 3
            error = (
                "VIP 멤버쉽이 종료되어 3개의 키워드의 순위만 노출됩니다. "
                "연장 관련 문의는 아래 카카오톡 채널을 통해 문의해주세요."
            )
        else:
            max_keywords = 10

        keywords = []

        if request.method == 'POST':

            if 'add_keyword' in request.form:
                new_keyword = request.form['new_keyword']
                result_fin = '-'
                cursor.execute(
                    'SELECT COUNT(*) AS count FROM (SELECT keyword FROM keyword_result WHERE user_id = %s AND place_id = %s GROUP BY keyword) as keyword_count', 
                    (user_id, place_id)
                )
                keyword_count = cursor.fetchone()
                
                if keyword_count[0] < max_keywords:
                    cursor.execute(
                        'INSERT INTO keyword_result (user_id, place_id, keyword, search_date) VALUES (%s, %s, %s, %s)',
                        (user_id, place_id, new_keyword, datetime.now().strftime('%Y-%m-%d'))
                    )
                    conn.commit()
                    keywords.append({'keyword': new_keyword, 'result': result_fin})
                else:
                    error = f'Maximum of {max_keywords} keywords reached.'
                    return render_template('Nplace-rank-check.html', username=session['username'], user_info=user_info, keywords=keywords, max_keywords=max_keywords, error=error)
            
            elif 'search' in request.form:
                keyword_id = request.form['keyword_id']
                result_thread = ThreadWithReturnValue(target=get_naver_rank, args=(keyword_id, place_id))
                result_thread.start()
                result_fin = result_thread.join()
                keywords.append({'keyword': keyword_id, 'result': result_fin})
            
            elif 'delete_keyword' in request.form:
                keyword_id = request.form['keyword_id']
                cursor.execute('DELETE FROM keyword_result WHERE user_id = %s AND place_id = %s AND keyword = %s',
                               (user_id, place_id, keyword_id))
                conn.commit()

        if user_info:
            cursor.execute('SELECT keyword, search_date, result FROM keyword_result WHERE user_id = %s AND place_id = %s ORDER BY search_date DESC', 
                           (user_id, place_id))
            keyword_results = cursor.fetchall()
            keywords_dict = {}
            for result in keyword_results:
                if result[0] not in keywords_dict:
                    keywords_dict[result[0]] = []
                keywords_dict[result[0]].append({'search_date': result[1], 'result': result[2]})

            keywords = [{'keyword': key, 'results': value} for key, value in keywords_dict.items()]

            if day_check.days < 0:
                keywords = keywords[:3]

        return render_template('Nplace-rank-check.html', username=session['username'], user_info=user_info, keywords=keywords, max_keywords=max_keywords, error=error if day_check.days < 0 else None)
    
    finally:
        # 데이터베이스 연결 닫기
        cursor.close()
        conn.close()


## IP당 24시간마다 3회 조회 가능
@app.route('/public-check', methods=['GET', 'POST'])
def search():
    error = None
    result = None

    # Get client IP address
    client_ip = request.remote_addr

    # Get IP-related search data from session
    ip_search_data = session.get('ip_search_data', {})

    if request.method == 'POST':
        now = datetime.now()

        # If this IP has a record in session
        if client_ip in ip_search_data:
            ip_info = ip_search_data[client_ip]
            search_times = ip_info.get('search_times', [])
            last_search_time = search_times[-1] if search_times else None

            # Ensure all times are offset-naive by converting to naive datetime
            search_times = [time.replace(tzinfo=None) for time in search_times]

            # Filter out searches older than 24 hours
            search_times = [time for time in search_times if now - time < timedelta(hours=24)]
            ip_info['search_times'] = search_times

            if len(search_times) > 3:
                error = 'IP당 24시간마다 최대 3회 조회가 가능합니다.'
            else:
                keyword = request.form['keyword']
                place_id = request.form['place_id']
                result = get_naver_rank_public(keyword, place_id)
                ip_info['search_times'].append(now)
                session['ip_search_data'] = ip_search_data
        else:
            # First search from this IP within 24 hours
            keyword = request.form['keyword']
            place_id = request.form['place_id']
            result = get_naver_rank_public(keyword, place_id)
            ip_search_data[client_ip] = {'search_times': [now]}
            session['ip_search_data'] = ip_search_data

    return render_template('public-check.html', result=result, error=error)

keyword_last_run = {}

@app.route('/run-now', methods=['POST'])
def run_now():
    main_conn = get_db_connection()
    cursor = main_conn.cursor()
    
    keyword_id = request.json.get('keyword_id')
    place_id = request.json.get('place_id')
    user_id = session['user_id']
    
    last_run = keyword_last_run.get(keyword_id)
    current_time = datetime.now()

    if last_run and (current_time - last_run) < timedelta(hours=8):
        time_left = timedelta(hours=8) - (current_time - last_run)
        return jsonify(success=False, message=f'이 키워드는 {time_left.seconds // 3600}시간 {time_left.seconds % 3600 // 60}분 후에 다시 실행할 수 있습니다.')

    try:
        result = get_naver_rank(keyword_id, place_id)
        keyword_last_run[keyword_id] = current_time
        cursor.execute(
            'INSERT INTO keyword_result (user_id, place_id, keyword, search_date, result) VALUES (%s, %s, %s, %s, %s)',
            (user_id, place_id, keyword_id, current_time.strftime('%Y-%m-%d'), result)
        )
        print('try 커밋')
        main_conn.commit()
        return jsonify(success=True, result=result)
    except Exception as e:
        cursor.execute(
            'UPDATE keyword_result SET result = %s WHERE user_id = %s AND place_id = %s AND keyword = %s AND search_date = %s',
            (result, user_id, place_id, keyword_id, current_time.strftime('%Y-%m-%d'))
        )
        print('except 커밋')
        main_conn.commit()
        return jsonify(success=True, result=result)  # Update success response here
    finally:
        cursor.close()
        main_conn.close()

if __name__ == '__main__':
    app.run(port=8080,debug=False,use_reloader=False, host='0.0.0.0', threaded=True)
    # flask_thread = threading.Thread(target=app.run, kwargs={'host': '0.0.0.0', 'port': 8080})
    # flask_thread.start()

    # # 스케줄러는 백그라운드에서 실행되도록 설정했으므로, 별도 처리 없이 정상 동작
    # flask_thread.join()  # Flask 웹 애플리케이션이 종료되지 않도록 유지